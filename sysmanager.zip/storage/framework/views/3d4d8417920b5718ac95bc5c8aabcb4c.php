<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title><?php echo e($document->document_number); ?></title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 720px; margin: 40px auto; color: #0f172a; }
        table { width: 100%; border-collapse: collapse; margin: 24px 0; }
        td { border: 1px solid #cbd5e1; padding: 8px 12px; }
        td:first-child { background: #f1f5f9; width: 35%; font-weight: bold; }
        .firmas { display: flex; justify-content: space-between; margin-top: 90px; }
        .firmas div { border-top: 1px solid #0f172a; width: 40%; text-align: center; padding-top: 6px; }
        @media print { button { display: none; } }
    </style>
</head>
<body>
    <button onclick="window.print()">Imprimir</button>
    <h1>Acta de entrega de activo</h1>
    <p>No. <?php echo e($document->document_number); ?> &middot; <?php echo e($document->generated_at->format('Y-m-d H:i')); ?></p>
    <table>
        <tr><td>Empresa</td><td><?php echo e($assignment->asset->company->name); ?></td></tr>
        <tr><td>Activo</td><td><?php echo e($assignment->asset->name); ?> (<?php echo e($assignment->asset->type); ?>)</td></tr>
        <tr><td>Marca / modelo</td><td><?php echo e($assignment->asset->brand); ?> <?php echo e($assignment->asset->model); ?></td></tr>
        <tr><td>Serial</td><td><?php echo e($assignment->asset->serial); ?></td></tr>
        <tr><td>Empleado</td><td><?php echo e($assignment->employee->name); ?></td></tr>
        <tr><td>Fecha de asignacion</td><td><?php echo e($assignment->assigned_at?->format('Y-m-d H:i')); ?></td></tr>
        <tr><td>Fecha de devolucion</td><td><?php echo e($assignment->returned_at?->format('Y-m-d H:i') ?? 'Pendiente'); ?></td></tr>
    </table>
    <div class="firmas"><div>Entrega</div><div>Recibe</div></div>
</body>
</html><?php /**PATH F:\DEV\LARAVEL\sysmanager\resources\views/documents/assignment.blade.php ENDPATH**/ ?>